"""
generate_data.py
-----------------
Generates a realistic SYNTHETIC dataset for the
"AI Public Transport Demand Predictor" project (Bengaluru edition).

Why synthetic data?
Real BMTC ridership data is not publicly released at a granular level,
so we simulate realistic passenger counts using domain-informed rules:
rush hour peaks, weekday/weekend patterns, weather effects, holidays,
nearby events, and route-specific base demand (IT corridor routes are
busier than residential-only routes).

Output: bengaluru_bus_demand.csv
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

# ---------------------------------------------------------------------
# 1. Real-style Bengaluru BMTC routes (route number + corridor name)
#    Base demand reflects typical corridor busy-ness (IT corridors >> others)
# ---------------------------------------------------------------------
ROUTES = [
    # route_id      corridor description                         base_demand  capacity
    ("500D",  "Silk Board - Electronic City",                       95,  60),
    ("500K",  "Kadugodi - Silk Board (Whitefield IT corridor)",     100, 60),
    ("G4",    "Banashankari - Whitefield (Volvo)",                  85,  45),
    ("V500",  "Banashankari - ITPL Whitefield (Vayu Vajra)",        80,  45),
    ("401K",  "Shivajinagar - Kadugodi",                            60,  60),
    ("201",   "Jayanagar - Hebbal",                                 55,  60),
    ("356CK", "Kempegowda Bus Stn - Electronic City",                90,  60),
    ("600",   "Banashankari - Silk Board (via BTM Layout)",         70,  60),
    ("KBS-3", "Majestic - Marathahalli",                            75,  60),
    ("MF-1",  "Yeshwanthpur - Koramangala",                         50,  60),
    ("V-500A","Kempegowda Bus Stn - Electronics City (Vajra)",       78,  45),
    ("280",   "Banashankari - Indiranagar",                         45,  60),
    ("45E",   "Jayanagar - Hebbal (via MG Road)",                   40,  60),
    ("500C",  "Silk Board - Marathahalli",                          65,  60),
    ("G9",    "Kadugodi - Kengeri (Volvo)",                         72,  45),
]

WEATHER_OPTIONS = ["Sunny", "Cloudy", "Light Rain", "Heavy Rain", "Extreme Heat"]
WEATHER_WEIGHTS = [0.45, 0.25, 0.18, 0.07, 0.05]

# Public/festival holidays relevant to Bengaluru/Karnataka calendar (sample set, illustrative)
HOLIDAYS = {
    "2025-01-26", "2025-03-14", "2025-04-14", "2025-05-01",
    "2025-08-15", "2025-08-27", "2025-10-02", "2025-10-21",
    "2025-11-01", "2025-12-25"
}

# Nearby "event" days per route (concerts/matches/tech-park events) - randomly assigned
EVENT_PROB = 0.06  # ~6% of route-days have a nearby event


def time_of_day_multiplier(hour):
    """Rush hour peaks: 8-10 AM and 5-7 PM."""
    if 8 <= hour <= 10:
        return 1.8
    elif 17 <= hour <= 19:
        return 2.0
    elif 11 <= hour <= 16:
        return 1.0
    elif 6 <= hour <= 7 or 20 <= hour <= 21:
        return 0.8
    else:
        return 0.35  # late night / early morning


def day_multiplier(day_name, is_holiday):
    if is_holiday:
        return 0.55
    if day_name in ["Saturday", "Sunday"]:
        return 0.6
    return 1.0


def weather_multiplier(weather):
    return {
        "Sunny": 1.0,
        "Cloudy": 0.97,
        "Light Rain": 0.85,
        "Heavy Rain": 0.55,
        "Extreme Heat": 0.8,
    }[weather]


def generate_dataset(start_date="2025-01-01", days=180, rows_per_day_per_route=6):
    """
    For each route, for each day, sample several times of day
    (mimicking scheduled trips) and simulate passenger counts.
    """
    records = []
    start = datetime.strptime(start_date, "%Y-%m-%d")

    sample_hours = [7, 9, 12, 15, 18, 21]  # representative trips per day

    prev_count_tracker = {}  # (route_id, hour) -> last known passenger count

    for d in range(days):
        current_date = start + timedelta(days=d)
        date_str = current_date.strftime("%Y-%m-%d")
        day_name = current_date.strftime("%A")
        is_holiday = date_str in HOLIDAYS

        weather = np.random.choice(WEATHER_OPTIONS, p=WEATHER_WEIGHTS)

        for route_id, corridor, base_demand, capacity in ROUTES:
            nearby_event = 1 if random.random() < EVENT_PROB else 0

            for hour in sample_hours:
                key = (route_id, hour)
                prev_count = prev_count_tracker.get(key, base_demand)

                tod_mult = time_of_day_multiplier(hour)
                dow_mult = day_multiplier(day_name, is_holiday)
                wthr_mult = weather_multiplier(weather)
                event_mult = 1.35 if nearby_event else 1.0

                expected = (
                    base_demand * tod_mult * dow_mult * wthr_mult * event_mult
                )
                # add random noise (+/- 12%)
                noise = np.random.normal(loc=0, scale=0.12)
                passengers = max(0, int(expected * (1 + noise)))

                records.append({
                    "date": date_str,
                    "day_of_week": day_name,
                    "is_weekend": 1 if day_name in ["Saturday", "Sunday"] else 0,
                    "hour": hour,
                    "route_id": route_id,
                    "corridor": corridor,
                    "bus_capacity": capacity,
                    "weather": weather,
                    "is_holiday": 1 if is_holiday else 0,
                    "nearby_event": nearby_event,
                    "prev_passenger_count": prev_count,
                    "passenger_count": passengers,
                })

                prev_count_tracker[key] = passengers

    df = pd.DataFrame(records)
    return df


if __name__ == "__main__":
    df = generate_dataset(start_date="2025-01-01", days=180)
    out_path = "bengaluru_bus_demand.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df.head(10))
    print("\nRoutes included:")
    print(df["route_id"].unique())
