# AI Public Transport Demand Predictor — Bengaluru (BMTC)

An ML-based decision-support system that predicts passenger demand on Bengaluru
BMTC bus routes and recommends whether an additional bus should be deployed.

Built for: Edunet Foundation AI/ML Workshop — Capstone Project

---

## 1. Problem Statement

City bus systems either overcrowd popular routes or run near-empty buses on
low-demand slots, because deployment decisions are usually static (fixed
schedules) rather than data-driven. This project predicts expected ridership
for a given **route + time + conditions**, classifies the demand level, and
recommends an operational action — turning a plain prediction into a usable
decision-support tool.

## 2. Project Architecture (2-stage design)

```
Inputs (day, time, route, weather, holiday, event, previous count)
        │
        ▼
 Stage 1: ML Regression Model (Random Forest)
        │  → predicts expected passenger_count
        ▼
 Stage 2: Rule-based Decision Engine
        │  → LOW / MEDIUM / HIGH demand level
        │  → actionable recommendation
        ▼
   Output shown in Streamlit dashboard
```

## 3. Dataset

Real BMTC ridership data is not publicly available at a granular
(route/hour) level, so a **domain-informed synthetic dataset** was generated
(`data/generate_data.py`) covering 15 real Bengaluru BMTC-style routes
(e.g. `500D` Silk Board–Electronic City, `500K` Whitefield IT corridor,
`G4` Banashankari–Whitefield Volvo) across 180 days, 6 representative
time slots/day → **16,200 rows**.

Simulation rules encode real transit behavior:
- Rush-hour multipliers (8–10 AM, 5–7 PM peaks)
- Weekend/holiday ridership drop
- Weather impact (heavy rain cuts ridership ~45%)
- Nearby-event demand spikes
- Route-specific base demand (IT corridors > residential routes)
- Random noise for realism

| Column | Description |
|---|---|
| date, day_of_week, is_weekend | Calendar features |
| hour | Trip hour (24h) |
| route_id, corridor, bus_capacity | Route info |
| weather | Sunny / Cloudy / Light Rain / Heavy Rain / Extreme Heat |
| is_holiday | Public holiday flag |
| nearby_event | Concert/match/tech-park event flag |
| prev_passenger_count | Last known count for that route/slot |
| passenger_count | **Target variable** |

## 4. Models

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression (baseline) | ~19.2 | ~26.2 | ~0.60 |
| **Random Forest (final)** | **~9.6** | **~14.0** | **~0.89** |

Random Forest was chosen as the final model — it captures non-linear
interactions (e.g. rush hour × rain × IT-corridor route) that linear
regression misses, while remaining explainable via feature importance.

**Top predictive features:** previous passenger count, weather, weekend flag,
route, day of week, hour of day.

## 5. Decision Engine (Stage 2)

```python
ratio = predicted_passengers / bus_capacity
if ratio >= 1.5:   → HIGH   → "Deploy an additional bus immediately"
elif ratio >= 1.0: → MEDIUM → "Keep a backup bus on standby"
else:              → LOW    → "Standard single-bus service is sufficient"
```

## 6. Project Structure

```
bengaluru_transport_demand/
├── data/
│   ├── generate_data.py          # synthetic dataset generator
│   └── bengaluru_bus_demand.csv  # generated dataset (16,200 rows)
├── model/
│   ├── demand_model.pkl          # trained Random Forest
│   ├── encoders.pkl              # label encoders + route metadata
│   ├── feature_importance.csv
│   ├── metrics.json
│   └── predictions.db            # SQLite log of every prediction made (auto-created)
├── train_model.py                # training + evaluation script
├── db.py                         # SQLite persistence layer
├── app.py                        # Streamlit dashboard (3 tabs: Predict / Heatmap / History)
├── requirements.txt
└── README.md
```

### Why SQLite instead of a WAMP/MySQL server?

This is a Python + Streamlit application, not a PHP application, so a WAMP
stack (Apache + MySQL + PHP) has nothing to attach to here — Streamlit runs
its own local web server directly. SQLite provides the same core benefit
(persistent storage, real SQL queries, a defined schema) without needing a
separate database server installed and running — the entire database lives
in one file, `model/predictions.db`. If the project is ever extended into a
multi-user web deployment, only `db.py` would need to change to point at a
MySQL/Postgres server instead.

### Dashboard tabs

1. **Predict** — enter trip details, get expected passengers via an
   interactive gauge, demand level, recommendation, and an hour-by-hour
   demand curve for that route/day. Every prediction is logged to SQLite.
2. **Route Demand Heatmap** — a route × hour heatmap (all 15 routes at
   once) showing predicted load as a percentage of bus capacity, for a
   chosen day/weather — useful for spotting which routes need attention.
3. **Prediction History** — pulls logged predictions back from SQLite,
   with a demand-level breakdown pie chart and a clearable log table.

## 7. How to Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) Regenerate the dataset
cd data && python generate_data.py && cd ..

# 3. Train the model
python train_model.py

# 4. Launch the dashboard
streamlit run app.py
```

## 8. Sample Output

```
Route: 500K (Whitefield IT corridor)
Day: Friday, Hour: 18:00, Weather: Sunny

Expected passengers: 187
Demand: 🔴 HIGH
Recommendation: Deploy an additional bus immediately
```

## 9. Possible Extensions (mention in viva as "future work")

- Replace synthetic data with real GTFS/open-data feeds if released by BMTC
- Add live weather API integration
- Multi-route optimization (reallocate buses across routes, not just add one)
- Time-series model (LSTM/Prophet) for longer-horizon forecasting

## 10. One-line Explanation (for viva)

> "This system predicts how many passengers will board a specific BMTC route
> at a specific time using weather, holiday, and historical ridership data,
> then automatically classifies the demand and recommends whether to deploy
> an extra bus — making it a decision-support tool, not just a prediction model."
