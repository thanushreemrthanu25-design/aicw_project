"""
app.py
------
Streamlit dashboard for the AI Public Transport Demand Predictor (Bengaluru BMTC).

Run with:
    streamlit run app.py

Features:
  - Random Forest passenger demand prediction
  - Rule-based demand level + recommendation engine
  - Plotly gauge, demand-curve, and hour x day heatmap visuals
  - SQLite-backed prediction history/log (persists across runs)
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import joblib
import json
import os

import db

st.set_page_config(page_title="Bengaluru Bus Demand Predictor", page_icon="🚌", layout="wide")

MODEL_DIR = "model"

# ---------------------------------------------------------------------
# BMTC-inspired theme
# ---------------------------------------------------------------------
BMTC_RED = "#C8102E"
BMTC_YELLOW = "#FFC72C"
BMTC_DARK = "#1E1E1E"
LOW_COLOR = "#2E7D32"
MED_COLOR = "#F9A825"
HIGH_COLOR = "#C62828"

st.markdown(f"""
<style>
    .main-header {{
        background: linear-gradient(90deg, {BMTC_RED} 0%, #8E0E22 100%);
        padding: 1.4rem 1.8rem;
        border-radius: 10px;
        margin-bottom: 1.2rem;
    }}
    .main-header h1 {{
        color: white;
        margin: 0;
        font-size: 1.7rem;
    }}
    .main-header p {{
        color: #FFE9E9;
        margin: 0.2rem 0 0 0;
        font-size: 0.95rem;
    }}
    div[data-testid="stMetric"] {{
        background-color: #FAFAFA;
        border: 1px solid #EAEAEA;
        border-radius: 8px;
        padding: 0.6rem 0.8rem;
    }}
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_artifacts():
    model = joblib.load(os.path.join(MODEL_DIR, "demand_model.pkl"))
    encoders = joblib.load(os.path.join(MODEL_DIR, "encoders.pkl"))
    with open(os.path.join(MODEL_DIR, "metrics.json")) as f:
        metrics = json.load(f)
    fi = pd.read_csv(os.path.join(MODEL_DIR, "feature_importance.csv"))
    return model, encoders, metrics, fi


def build_recommendation(passengers, capacity):
    ratio = passengers / capacity
    if ratio >= 1.5:
        return "HIGH", HIGH_COLOR, "Deploy an additional bus immediately"
    elif ratio >= 1.0:
        return "MEDIUM", MED_COLOR, "Keep a backup bus on standby / monitor closely"
    else:
        return "LOW", LOW_COLOR, "Standard single-bus service is sufficient"


def make_gauge(predicted, capacity, level, color):
    max_val = max(capacity * 2, predicted * 1.2, 10)
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=predicted,
        number={"suffix": " pax", "font": {"size": 34}},
        title={"text": f"Demand: {level}", "font": {"size": 18}},
        gauge={
            "axis": {"range": [0, max_val]},
            "bar": {"color": color, "thickness": 0.3},
            "steps": [
                {"range": [0, capacity], "color": "#E8F5E9"},
                {"range": [capacity, capacity * 1.5], "color": "#FFF8E1"},
                {"range": [capacity * 1.5, max_val], "color": "#FFEBEE"},
            ],
            "threshold": {
                "line": {"color": BMTC_DARK, "width": 3},
                "thickness": 0.85,
                "value": capacity,
            },
        }
    ))
    fig.update_layout(height=280, margin=dict(l=20, r=20, t=50, b=10))
    return fig


def predict_row(model, encoders, feature_cols, day_of_week, hour, route_id,
                 weather, is_holiday, nearby_event, prev_count, capacity):
    le_day, le_route, le_weather = encoders["le_day"], encoders["le_route"], encoders["le_weather"]
    is_weekend = 1 if day_of_week in ["Saturday", "Sunday"] else 0
    row = pd.DataFrame([{
        "day_of_week_enc": le_day.transform([day_of_week])[0],
        "is_weekend": is_weekend,
        "hour": hour,
        "route_id_enc": le_route.transform([route_id])[0],
        "weather_enc": le_weather.transform([weather])[0],
        "is_holiday": int(is_holiday),
        "nearby_event": int(nearby_event),
        "prev_passenger_count": prev_count,
        "bus_capacity": capacity,
    }])[feature_cols]
    return max(0, round(model.predict(row)[0]))


# ---------------------------------------------------------------------
db.init_db()
model, encoders, metrics, fi = load_artifacts()
route_meta = encoders["route_meta"]
le_day = encoders["le_day"]
le_route = encoders["le_route"]
le_weather = encoders["le_weather"]
feature_cols = encoders["feature_cols"]

st.markdown("""
<div class="main-header">
    <h1>🚌 AI Public Transport Demand Predictor</h1>
    <p>Bengaluru BMTC routes — ML-driven passenger demand forecasting and bus deployment recommendations</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("Model Performance")
    c1, c2 = st.columns(2)
    c1.metric("R² Score", f"{metrics['random_forest']['r2']:.3f}")
    c2.metric("MAE", f"{metrics['random_forest']['mae']:.1f}")
    st.caption("Random Forest vs Linear Regression baseline "
               f"(baseline R² = {metrics['linear_regression']['r2']:.3f})")
    st.divider()
    st.subheader("Feature Importance")
    fi_sorted = fi.sort_values("importance", ascending=True)
    fig_fi = px.bar(fi_sorted, x="importance", y="feature", orientation="h",
                     color="importance", color_continuous_scale=["#FFE0B2", BMTC_RED])
    fig_fi.update_layout(height=320, showlegend=False, coloraxis_showscale=False,
                          margin=dict(l=10, r=10, t=10, b=10))
    st.plotly_chart(fig_fi, use_container_width=True)

tab_predict, tab_heatmap, tab_history = st.tabs(
    ["🔮 Predict", "🗺️ Route Demand Heatmap", "📜 Prediction History"]
)

# =======================================================================
# TAB 1: PREDICT
# =======================================================================
with tab_predict:
    st.subheader("Enter trip details")

    col1, col2 = st.columns(2)
    with col1:
        route_id = st.selectbox("Route", options=sorted(route_meta.index.tolist()),
                                 format_func=lambda r: f"{r} — {route_meta.loc[r, 'corridor']}")
        day_of_week = st.selectbox("Day of week", options=list(le_day.classes_))
        hour = st.slider("Hour of day (24h)", min_value=5, max_value=23, value=17)
    with col2:
        weather = st.selectbox("Weather", options=list(le_weather.classes_))
        is_holiday = st.checkbox("Public holiday?")
        nearby_event = st.checkbox("Nearby event (concert / match / tech-park event)?")

    capacity = int(route_meta.loc[route_id, "bus_capacity"])
    prev_count = st.slider(
        "Previous known passenger count for this route/time slot",
        min_value=0, max_value=250, value=capacity,
        help="Historical passenger count for this route at a similar time — the single strongest predictor."
    )

    if st.button("Predict Demand", type="primary", use_container_width=True):
        predicted = predict_row(model, encoders, feature_cols, day_of_week, hour,
                                 route_id, weather, is_holiday, nearby_event, prev_count, capacity)
        level, color, recommendation = build_recommendation(predicted, capacity)

        db.log_prediction({
            "route_id": route_id,
            "corridor": route_meta.loc[route_id, "corridor"],
            "day_of_week": day_of_week,
            "hour": hour,
            "weather": weather,
            "is_holiday": int(is_holiday),
            "nearby_event": int(nearby_event),
            "prev_passenger_count": prev_count,
            "bus_capacity": capacity,
            "predicted_passengers": predicted,
            "demand_level": level,
            "recommendation": recommendation,
        })

        st.divider()
        res_col1, res_col2 = st.columns([1, 1.3])

        with res_col1:
            st.plotly_chart(make_gauge(predicted, capacity, level, color), use_container_width=True)
            st.markdown(
                f"<div style='background-color:{color}22; border-left:5px solid {color}; "
                f"padding:0.7rem 1rem; border-radius:6px;'>"
                f"<b>Recommendation:</b> {recommendation}</div>",
                unsafe_allow_html=True
            )
            st.caption(f"Route capacity: {capacity} passengers/bus | "
                       f"Predicted load: {predicted / capacity * 100:.0f}% of single-bus capacity")

        with res_col2:
            st.markdown(f"**Demand curve — Route {route_id} on a {day_of_week}**")
            hours_range = list(range(5, 24))
            preds = [predict_row(model, encoders, feature_cols, day_of_week, h, route_id,
                                  weather, is_holiday, nearby_event, prev_count, capacity)
                     for h in hours_range]
            curve_df = pd.DataFrame({"hour": hours_range, "predicted_passengers": preds})

            fig_curve = px.area(curve_df, x="hour", y="predicted_passengers",
                                 color_discrete_sequence=[BMTC_RED])
            fig_curve.add_hline(y=capacity, line_dash="dash", line_color=BMTC_DARK,
                                 annotation_text="Bus capacity", annotation_position="top left")
            fig_curve.add_vline(x=hour, line_dash="dot", line_color=BMTC_YELLOW)
            fig_curve.update_traces(line=dict(width=3))
            fig_curve.update_layout(height=280, margin=dict(l=10, r=10, t=20, b=10),
                                     xaxis_title="Hour of day", yaxis_title="Expected passengers")
            st.plotly_chart(fig_curve, use_container_width=True)

# =======================================================================
# TAB 2: ROUTE DEMAND HEATMAP
# =======================================================================
with tab_heatmap:
    st.subheader("Predicted demand across all routes and hours")
    hm_col1, hm_col2, hm_col3 = st.columns(3)
    hm_day = hm_col1.selectbox("Day of week", options=list(le_day.classes_), key="hm_day")
    hm_weather = hm_col2.selectbox("Weather", options=list(le_weather.classes_), key="hm_weather")
    hm_holiday = hm_col3.checkbox("Public holiday?", key="hm_holiday")

    hours_range = list(range(5, 24))
    routes = sorted(route_meta.index.tolist())
    matrix = []
    for r in routes:
        cap = int(route_meta.loc[r, "bus_capacity"])
        row_vals = [
            predict_row(model, encoders, feature_cols, hm_day, h, r, hm_weather,
                        hm_holiday, False, cap, cap) / cap * 100
            for h in hours_range
        ]
        matrix.append(row_vals)

    heat_df = pd.DataFrame(matrix, index=routes, columns=hours_range)
    fig_hm = px.imshow(
        heat_df, aspect="auto", color_continuous_scale=["#2E7D32", "#F9A825", "#C62828"],
        labels=dict(x="Hour of day", y="Route", color="% of bus capacity"),
        zmin=0, zmax=200
    )
    fig_hm.update_layout(height=520, margin=dict(l=10, r=10, t=10, b=10))
    st.plotly_chart(fig_hm, use_container_width=True)
    st.caption("Darker red = predicted load far exceeds single-bus capacity → strong candidate "
               "for extra bus deployment at that hour. Assumes previous count ≈ route capacity.")

# =======================================================================
# TAB 3: PREDICTION HISTORY (SQLite-backed)
# =======================================================================
with tab_history:
    st.subheader("Logged predictions")
    history_df = db.fetch_history(limit=500)

    if history_df.empty:
        st.info("No predictions logged yet. Make a prediction in the 'Predict' tab — it will "
                "be saved here automatically (stored in model/predictions.db).")
    else:
        counts = db.demand_level_counts()
        c1, c2, c3 = st.columns(3)
        for level, col, color in [("LOW", c1, LOW_COLOR), ("MEDIUM", c2, MED_COLOR), ("HIGH", c3, HIGH_COLOR)]:
            n = int(counts.loc[counts["demand_level"] == level, "count"].sum()) if level in counts["demand_level"].values else 0
            col.metric(f"{level} demand logs", n)

        fig_pie = px.pie(counts, names="demand_level", values="count",
                          color="demand_level",
                          color_discrete_map={"LOW": LOW_COLOR, "MEDIUM": MED_COLOR, "HIGH": HIGH_COLOR})
        fig_pie.update_layout(height=300, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig_pie, use_container_width=True)

        st.dataframe(
            history_df[["timestamp", "route_id", "day_of_week", "hour", "weather",
                        "predicted_passengers", "demand_level", "recommendation"]],
            use_container_width=True, height=350
        )

        if st.button("Clear history"):
            db.clear_history()
            st.rerun()

st.divider()
st.caption("Built for Edunet Foundation AI/ML workshop project — synthetic BMTC-style data, "
           "Random Forest regression, rule-based recommendation engine, and SQLite prediction logging.")
