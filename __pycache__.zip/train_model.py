"""
train_model.py
---------------
Trains the AI Public Transport Demand Predictor for Bengaluru BMTC routes.

Two-stage design:
  Stage 1 (ML Regression): predict expected passenger_count
  Stage 2 (Rule engine):   convert prediction -> LOW/MEDIUM/HIGH demand
                            + actionable recommendation

Models compared:
  - Linear Regression (baseline)
  - Random Forest Regressor (final model)

Outputs:
  model/demand_model.pkl       -> trained RandomForest model
  model/encoders.pkl           -> label encoders + route metadata
  model/feature_importance.csv -> for report/demo
  model/metrics.json           -> R2 / MAE for both models
"""

import pandas as pd
import numpy as np
import joblib
import json
import os

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error

DATA_PATH = "data/bengaluru_bus_demand.csv"
MODEL_DIR = "model"
os.makedirs(MODEL_DIR, exist_ok=True)


def build_recommendation(passengers, capacity):
    """Stage 2: rule-based decision layer."""
    ratio = passengers / capacity
    if ratio >= 1.5:
        return "HIGH", "Deploy an additional bus immediately"
    elif ratio >= 1.0:
        return "MEDIUM", "Keep a backup bus on standby / monitor closely"
    else:
        return "LOW", "Standard single-bus service is sufficient"


def main():
    df = pd.read_csv(DATA_PATH)
    print(f"Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")

    # ---------------- Encode categorical features ----------------
    le_day = LabelEncoder()
    le_route = LabelEncoder()
    le_weather = LabelEncoder()

    df["day_of_week_enc"] = le_day.fit_transform(df["day_of_week"])
    df["route_id_enc"] = le_route.fit_transform(df["route_id"])
    df["weather_enc"] = le_weather.fit_transform(df["weather"])

    feature_cols = [
        "day_of_week_enc", "is_weekend", "hour", "route_id_enc",
        "weather_enc", "is_holiday", "nearby_event",
        "prev_passenger_count", "bus_capacity"
    ]
    target_col = "passenger_count"

    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # ---------------- Baseline: Linear Regression ----------------
    lin_model = LinearRegression()
    lin_model.fit(X_train, y_train)
    lin_pred = lin_model.predict(X_test)
    lin_mae = mean_absolute_error(y_test, lin_pred)
    lin_r2 = r2_score(y_test, lin_pred)
    lin_rmse = np.sqrt(mean_squared_error(y_test, lin_pred))

    # ---------------- Final model: Random Forest ----------------
    rf_model = RandomForestRegressor(
        n_estimators=120,
        max_depth=10,
        min_samples_leaf=5,
        random_state=42,
        n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    rf_pred = rf_model.predict(X_test)
    rf_mae = mean_absolute_error(y_test, rf_pred)
    rf_r2 = r2_score(y_test, rf_pred)
    rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))

    print("\n--- Model Comparison ---")
    print(f"Linear Regression -> MAE: {lin_mae:.2f} | RMSE: {lin_rmse:.2f} | R2: {lin_r2:.3f}")
    print(f"Random Forest      -> MAE: {rf_mae:.2f} | RMSE: {rf_rmse:.2f} | R2: {rf_r2:.3f}")

    # ---------------- Feature importance ----------------
    importances = pd.DataFrame({
        "feature": feature_cols,
        "importance": rf_model.feature_importances_
    }).sort_values("importance", ascending=False)
    importances.to_csv(os.path.join(MODEL_DIR, "feature_importance.csv"), index=False)
    print("\nFeature importance:")
    print(importances)

    # ---------------- Save model + encoders ----------------
    joblib.dump(rf_model, os.path.join(MODEL_DIR, "demand_model.pkl"), compress=3)

    route_meta = df[["route_id", "corridor", "bus_capacity"]].drop_duplicates()
    route_meta = route_meta.set_index("route_id")

    encoders = {
        "le_day": le_day,
        "le_route": le_route,
        "le_weather": le_weather,
        "route_meta": route_meta,
        "feature_cols": feature_cols,
    }
    joblib.dump(encoders, os.path.join(MODEL_DIR, "encoders.pkl"))

    metrics = {
        "linear_regression": {"mae": lin_mae, "rmse": lin_rmse, "r2": lin_r2},
        "random_forest": {"mae": rf_mae, "rmse": rf_rmse, "r2": rf_r2},
    }
    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    print("\nSaved: model/demand_model.pkl, model/encoders.pkl, "
          "model/feature_importance.csv, model/metrics.json")

    # ---------------- Quick sanity test ----------------
    sample = X_test.iloc[[0]]
    pred = rf_model.predict(sample)[0]
    cap = df.loc[sample.index[0], "bus_capacity"]
    level, rec = build_recommendation(pred, cap)
    print(f"\nSample prediction: {pred:.0f} passengers -> {level} -> {rec}")


if __name__ == "__main__":
    main()
