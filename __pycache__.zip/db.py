"""
db.py
-----
Lightweight SQLite persistence layer for the Bengaluru Bus Demand Predictor.

Why SQLite (instead of a WAMP/MySQL server)?
This is a Python/Streamlit app, not a PHP app, so a WAMP stack (Apache +
MySQL + PHP) doesn't attach to it. SQLite gives the same real-database
benefit — persistent storage, SQL queries, a proper schema — without
requiring a separate server to install and run. The whole database is a
single file: model/predictions.db.

If a real MySQL/WAMP backend is later required (e.g. for a multi-user
web deployment), only this file needs to change — the rest of the app
talks to it through the functions below, not raw SQL.
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join("model", "predictions.db")


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    return conn


def init_db():
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            route_id TEXT NOT NULL,
            corridor TEXT,
            day_of_week TEXT,
            hour INTEGER,
            weather TEXT,
            is_holiday INTEGER,
            nearby_event INTEGER,
            prev_passenger_count INTEGER,
            bus_capacity INTEGER,
            predicted_passengers INTEGER,
            demand_level TEXT,
            recommendation TEXT
        )
    """)
    conn.commit()
    conn.close()


def log_prediction(record: dict):
    """record must contain all columns except id/timestamp."""
    conn = get_connection()
    conn.execute("""
        INSERT INTO predictions (
            timestamp, route_id, corridor, day_of_week, hour, weather,
            is_holiday, nearby_event, prev_passenger_count, bus_capacity,
            predicted_passengers, demand_level, recommendation
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        record["route_id"], record["corridor"], record["day_of_week"],
        record["hour"], record["weather"], record["is_holiday"],
        record["nearby_event"], record["prev_passenger_count"],
        record["bus_capacity"], record["predicted_passengers"],
        record["demand_level"], record["recommendation"],
    ))
    conn.commit()
    conn.close()


def fetch_history(limit=200):
    import pandas as pd
    conn = get_connection()
    df = pd.read_sql_query(
        f"SELECT * FROM predictions ORDER BY id DESC LIMIT {limit}", conn
    )
    conn.close()
    return df


def demand_level_counts():
    import pandas as pd
    conn = get_connection()
    df = pd.read_sql_query(
        "SELECT demand_level, COUNT(*) as count FROM predictions GROUP BY demand_level",
        conn
    )
    conn.close()
    return df


def clear_history():
    conn = get_connection()
    conn.execute("DELETE FROM predictions")
    conn.commit()
    conn.close()
